<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Api extends CI_Controller {
	function __construct(){
	    parent::__construct();
		$this->load->model('user');
        $this->load->get_templates();
	}

	public function index(){
		$ac = $this->input->get('ac',true);
		$rid = (int)$this->input->get('rid',true);
		$wd = $this->input->get('wd',true);
		$cid = (int)$this->input->get('t',true);
		$h = (int)$this->input->get('h',true);
		$ids = $this->input->get('ids',true);
		$page = (int)$this->input->get('pg',true);
		//SQL filtering
		$wd = safe_replace(rawurldecode($wd));
		if($ac!=='list') $ac='vod';

		$where = $like = array();
		$where['vip'] = 0;
		//Classification
		if($cid>0) $where['cid'] = $cid;
		//Number of days
		if($h>0){
			if($h==24){
				$time = strtotime(date('Y-m-d'));
				$where['addtime>'] = $time;
			}else{
				$time1 = time()-3600*$h;
				$time2 = date('Y-m-d 0:0:0',$time1);
				$time = strtotime($time2);
				$where['addtime>'] = $time;
			}
		}
		//Search
		if(!empty($wd)) $like['name'] = $wd;

		//Select collection
		if(preg_match('/^([0-9]+[,]?)+$/', $ids)){
			$where['id'] = $ids;
		}

		//Quantity per page
		$size = 30;
		//The total amount
		$nums = $this->csdb->get_nums('vod',$where,$like);
		//Total pages
		$pagejs = ceil($nums / $size);
		if($page > $pagejs) $page=$pagejs;
		if($page==0) $page = 1;
		if($nums<$size) $size=$nums;
		//Offset
		$limit = array($size,$size*($page-1));
		//Datasheets
		$data['vod'] = $this->csdb->get_select('vod','*',$where,'addtime desc',$limit,$like);
		//Secondary classification
		if($ac=='list'){
			$data['class'] = $this->csdb->get_select('class','*','','xid asc',50);
		}else{
			$data['class'] = array();
		}
		$data['page'] = $page;
		$data['pagejs'] = $pagejs;
		$data['nums'] = $nums;
		$data['size'] = $size;
		header("Content-type:text/xml;charset=utf-8");
		$this->load->view('api/'.$ac.'.tpl',$data);
	}

	//VIP member
	public function vip($user = ''){
		if(empty($user)) exit('VIP account is empty');
		$res = $this->csdb->get_row('user','id,vip',array('name'=>safe_replace($user)));
		if(!$res || $res->vip == 0) exit('VIP account does not exist');
		$ac = $this->input->get('ac',true);
		$rid = (int)$this->input->get('rid',true);
		$wd = $this->input->get('wd',true);
		$cid = (int)$this->input->get('t',true);
		$h = (int)$this->input->get('h',true);
		$ids = $this->input->get('ids',true);
		$page = (int)$this->input->get('pg',true);
		//SQL filtering
		$wd = safe_replace(rawurldecode($wd));
		if($ac!=='list') $ac='vod';

		$where = $like = array();
		$where['uid'] = $res->id;
		//Classification
		if($cid>0) $where['cid'] = $cid;
		//Number of days
		if($h>0){
			if($h==24){
				$time = strtotime(date('Y-m-d'));
				$where['addtime>'] = $time;
			}else{
				$time1 = time()-3600*$h;
				$time2 = date('Y-m-d 0:0:0',$time1);
				$time = strtotime($time2);
				$where['addtime>'] = $time;
			}
		}
		//Search
		if(!empty($wd)) $like['name'] = $wd;

		//Select collection
		if(preg_match('/^([0-9]+[,]?)+$/', $ids)){
			$where['id'] = $ids;
		}

		//Quantity per page
		$size = 30;
		//The total amount
		$nums = $this->csdb->get_nums('vod',$where,$like);
		//Total pages
		$pagejs = ceil($nums / $size);
		if($page > $pagejs) $page=$pagejs;
		if($page==0) $page = 1;
		if($nums<$size) $size=$nums;
		//Offset
		$limit = array($size,$size*($page-1));
		//Datasheets
		$data['vod'] = $this->csdb->get_select('vod','*',$where,'addtime desc',$limit,$like);
		//Secondary classification
		if($ac=='list'){
			$data['class'] = $this->csdb->get_select('class','*','','xid asc',50);
		}else{
			$data['class'] = array();
		}
		$data['page'] = $page;
		$data['pagejs'] = $pagejs;
		$data['nums'] = $nums;
		$data['size'] = $size;
		header("Content-type:text/xml;charset=utf-8");
		$this->load->view('api/'.$ac.'.tpl',$data);
	}

	public function upload(){
		if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
			return $this->output
			->set_content_type('application/json')
			->set_status_header(200)
			->set_output(json_encode([
				'status' => 'error',
				'msg' => 'Method is not allowed!',
			]));
		}
		try {
			set_time_limit(0);
			$apikey = trim($this->input->get_post('apikey'));
			$cid = $this->input->get_post('cid');
			$mycid = $this->input->get_post('mycid');
			$fid = $this->input->get_post('fid');

			if (empty($apikey)) {
				return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'apikey is required!'
				]));
			}
			if (empty($cid)) {
				return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'cid is required!'
				]));
			}
			if (empty($fid)) {
				return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'fid is required!'
				]));
			}
		
			$user = $this->csdb->get_row('user','*',array( 'apikey' => $apikey));
			if (!$user) {
				return $this->output
				->set_content_type('application/json')
				->set_status_header(401)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'Unauthorized!'
				]));
			}
			$add['uid'] = $user->id;

			$videoclass = $this->csdb->get_row('class','*',array('id' => $cid));
			if (!$videoclass) {
				return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'cid is not correct!'
				]));
			}
			$add['cid'] = $cid;

			if ($mycid) {
				$myclass = $this->csdb->get_row('myclass','*',array('id' => $mycid,'uid' => $user->id, 'fid' => 0));
				if (!$myclass) {
					return $this->output
					->set_content_type('application/json')
					->set_status_header(200)
					->set_output(json_encode([
						'status' => 'error',
						'msg' => 'mycid is not correct!'
					]));
				}
				$add['mycid'] = $mycid;
			} 
		
			$server = $this->csdb->get_row('server','*',array('id' => $fid,'vip' => $user->vip));
			if (!$server) {
				return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'fid is not correct!'
				]));
			}
			$add['fid'] = $fid;
			
			if(substr(Up_Dir,0,2) == './'){
				$Video_Path = FCPATH.substr(Up_Dir,2);
			}else{
				$Video_Path = Up_Dir;
			}
			//Shard folder
			$targetDir = $Video_Path.'/temp/'.date('Ymd').'/';
			//Save the drive letter path
			$uploadDir = $Video_Path.'/'.date('Ym').'/';
			$uploadStr = date('Ym').'/';
			//Defines the file extensions that are allowed to be uploaded
			$ext_arr = array_filter(explode('|', Up_Ext));
			
			
			//Create a directory
			if (!file_exists($targetDir)) { 
				mkdirss($targetDir); 
			} 
			//Create a directory
			if (!file_exists($uploadDir)) { 
				mkdirss($uploadDir); 
			}
			//Original file name
			if(!isset($_FILES['video']['name'])){
				return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'No file!'
				]));
			}
			$file_name = $_FILES['video']['name'];
			//File extension
			$file_ext = strtolower(trim(substr(strrchr($file_name, '.'), 1)));
			$newname = iconv("UTF-8","GBK//IGNORE",$file_name);
			$video_name = safe_replace(str_replace('.'.$file_ext, '', $file_name));
			//Determine the file suffix
			if(in_array($file_ext, $ext_arr) === false)  getjson("Unsupported video format");
			//Check if the song exists
			$res = $this->csdb->get_row('vod','id',array('name'=>$video_name,'uid'=>$add['uid']));
			if($res) getjson("The video already exists, no need to upload it again");

			if ($res) {
				return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'The video already exists, no need to upload it again'
				]));
			}
			//Generate a unique MD5 based on the file name and member ID
			$fileName = md5($file_name.$add['uid']).'.'.$file_ext;
			$oldName = $fileName;
			$filePath = $targetDir . DIRECTORY_SEPARATOR . $fileName; 
			//Fragment ID
			$chunk = isset($_REQUEST["chunk"]) ? intval($_REQUEST["chunk"]) : 0; 
			//Total number of shards
			$chunks = isset($_REQUEST["chunks"]) ? intval($_REQUEST["chunks"]) : 1;  
			//Open temporary file 
			if (!$out = @fopen("{$filePath}_{$chunk}.parttmp", "wb")) { 

				return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'Failed to open output stream.'
				]));
			} 
			if (!empty($_FILES)) {
				if ($_FILES["video"]["error"] || !is_uploaded_file($_FILES["video"]["tmp_name"])) { 
					return $this->output
						->set_content_type('application/json')
						->set_status_header(200)
						->set_output(json_encode([
							'status' => 'error',
							'msg' => 'Failed to move uploaded file.'
						]));
				} 
				//Read a binary input stream and append it to a temporary file
				if (!$in = @fopen($_FILES["video"]["tmp_name"], "rb")) { 
					return $this->output
						->set_content_type('application/json')
						->set_status_header(200)
						->set_output(json_encode([
							'status' => 'error',
							'msg' => 'Failed to open input stream.'
						]));
				} 
			} else { 
				if (!$in = @fopen("php://input", "rb")) { 
					return $this->output
						->set_content_type('application/json')
						->set_status_header(200)
						->set_output(json_encode([
							'status' => 'error',
							'msg' => 'Failed to open input stream.'
						]));
				}
			} 
			while ($buff = fread($in, 4096)) { 
				fwrite($out, $buff); 
			} 
			@fclose($out); 
			@fclose($in); 
			rename("{$filePath}_{$chunk}.parttmp", "{$filePath}_{$chunk}.part"); 
			$index = 0; 
			$done = true; 
			for( $index = 0; $index < $chunks; $index++ ) { 
				if(!file_exists("{$filePath}_{$index}.part") ) { 
					$done = false; 
					break; 
				} 
			}
			if($done){ 
				$pathInfo = pathinfo($fileName); 
				$hashStr = substr(md5($pathInfo['basename']),8,5);
				$hashName = date('YmdHis').$hashStr.'.'.$pathInfo['extension']; 
				$uploadPath = $uploadDir.$hashName;
				if (!$out = @fopen($uploadPath, "wb")) { 
					return $this->output
						->set_content_type('application/json')
						->set_status_header(200)
						->set_output(json_encode([
							'status' => 'error',
							'msg' => 'Failed to open output stream.'
						]));
				} 
				if ( flock($out, LOCK_EX) ) { 
					for( $index = 0; $index < $chunks; $index++ ) { 
						if (!$in = @fopen("{$filePath}_{$index}.part", "rb")) { 
							break; 
						} 
						while ($buff = fread($in, 4096)) { 
							fwrite($out, $buff); 
						} 
						@fclose($in); 
						@unlink("{$filePath}_{$index}.part"); 
					} 
					flock($out, LOCK_UN); 
				} 
				@fclose($out);
				//video
				$add['name'] = $video_name;
				$add['filepath'] = $uploadPath;
				$add['addtime'] = time();
				$this->load->library('ffmpeg');
				$format = $this->ffmpeg->format($uploadPath);
				if(empty($format['size']) || empty($format['duration'])){
					unlink($uploadPath);
					return $this->output
						->set_content_type('application/json')
						->set_status_header(200)
						->set_output(json_encode([
							'status' => 'error',
							'msg' => 'ffmpeg error'
						]));
				}
				$add['duration'] = $format['duration'];
				$add['size'] = $format['size'];
				$add['vid'] = get_vid(rand(1111,9999));
				$did = $this->csdb->get_insert("vod",$add);

				return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'success',
					'msg' => 'Video upload complete',
					'did' => $did
				]));
			}
			
			
			return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'Some thing wrong'
				]));
		} catch (\Exeption $e) {
			return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'Some thing wrong: '
				]));
		}
		
	}

	public function getserver()
	{
		if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
			return $this->output
			->set_content_type('application/json')
			->set_status_header(200)
			->set_output(json_encode([
				'status' => 'error',
				'msg' => 'Method is not allowed!',
			]));
		}
		$apikey = trim($this->input->get('apikey'));
	
		if (empty($apikey)) {
			return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'apikey is required!'
				]));
		}
		
		$user = $this->csdb->get_row('user','*',array( 'apikey' => $apikey));
		if (!$user) {
			return $this->output
			->set_content_type('application/json')
			->set_status_header(401)
			->set_output(json_encode([
				'status' => 'error',
				'msg' => 'Unauthorized!'
			]));
		}

		$servers = $this->csdb->get_select('server','*',array('vip'=>$user->vip),'id ASC',100);
		$result = [];
		
		foreach ($servers as $server) {
			$result[] = [
				$server->id => $server->name
			];
		}

		
		return $this->output
			->set_content_type('application/json')
			->set_status_header(200)
			->set_output(json_encode([
				'status' => 'success',
				'msg' => '',
				'data' => $result
			]));
	}

	public function getvideoclass()
	{
		if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
			return $this->output
			->set_content_type('application/json')
			->set_status_header(200)
			->set_output(json_encode([
				'status' => 'error',
				'msg' => 'Method is not allowed!',
			]));
		}
		$apikey = trim($this->input->get('apikey'));
	
		if (empty($apikey)) {
			return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'apikey is required!'
				]));
		}
		
		$user = $this->csdb->get_row('user','*',array( 'apikey' => $apikey));
		if (!$user) {
			return $this->output
			->set_content_type('application/json')
			->set_status_header(401)
			->set_output(json_encode([
				'status' => 'error',
				'msg' => 'Unauthorized!'
			]));
		}

		$classes = $this->csdb->get_select('class','*',array(),'id ASC',30);
		$result = [];
		
		foreach ($classes as $class) {
			$result[] = [
				$class->id => $class->name
			];
		}
		return $this->output
			->set_content_type('application/json')
			->set_status_header(200)
			->set_output(json_encode([
				'status' => 'success',
				'msg' => '',
				'data' => $result
			]));
	}

	public function getmyclass()
	{
		if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
			return $this->output
			->set_content_type('application/json')
			->set_status_header(200)
			->set_output(json_encode([
				'status' => 'error',
				'msg' => 'Method is not allowed!',
			]));
		}
		$apikey = trim($this->input->get('apikey'));
	
		if (empty($apikey)) {
			return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'apikey is required!'
				]));
		}
		
		$user = $this->csdb->get_row('user','*',array( 'apikey' => $apikey));
		if (!$user) {
			return $this->output
			->set_content_type('application/json')
			->set_status_header(401)
			->set_output(json_encode([
				'status' => 'error',
				'msg' => 'Unauthorized!'
			]));
		}

		$myclass = $this->csdb->get_select('myclass','*',array('uid'=>$user->id,'fid'=>0),'id ASC',30);
		$result = [];
		
		foreach ($myclass as $class) {
			$result[] = [
				$class->id => $class->name
			];
		}
		return $this->output
			->set_content_type('application/json')
			->set_status_header(200)
			->set_output(json_encode([
				'status' => 'success',
				'msg' => '',
				'data' => $result
			]));
	}

	public function myvideo()
	{
		if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
			return $this->output
			->set_content_type('application/json')
			->set_status_header(200)
			->set_output(json_encode([
				'status' => 'error',
				'msg' => 'Method is not allowed!',
			]));
		}
		$apikey = trim($this->input->get('apikey'));
		if (empty($apikey)) {
			return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode([
					'status' => 'error',
					'msg' => 'apikey is required!'
				]));
		}
		
		$user = $this->csdb->get_row('user','*',array( 'apikey' => $apikey));
		if (!$user) {
			return $this->output
			->set_content_type('application/json')
			->set_status_header(401)
			->set_output(json_encode([
				'status' => 'error',
				'msg' => 'Unauthorized!'
			]));
		}

		$myvideos = $this->csdb->get_select('vod','*',array('uid'=>$user->id),'id DESC',30);

		$result = [];

		$classes = $this->csdb->get_select('class','*',array(),'id ASC');
		$cids = [];
		
		foreach ($classes as $class) {
			$cids[$class->id] = $class->name;
		}

		foreach ($myvideos as $myvideo) {
			if (array_key_exists($myvideo->cid, $cids)) {
				$cid = $cids[$myvideo->cid];
			} else {
				$cid = $myvideo->cid;
			}
			$result[] = [
					'id' => $myvideo->id,
					'vid' => $myvideo->vid,
					'name' => $myvideo->name,
					'cid' => $cid,
					'hits' => $myvideo->hits,
					'duration' => formattime($myvideo->duration,1),
					'size' => formatsize($myvideo->size),
					'uid' => $myvideo->uid,
					'addtime' => date('d-m-Y | H:i:s',$myvideo->addtime),
					'iframe' => '<iframe width="100%" height="100%" src="' . 'https://'.Web_Url.links('play','index',$myvideo->vid) . '" frameborder="0" allowfullscreen></iframe>',
					'link' => 'https://'.Web_Url.links('play','index',$myvideo->vid),
					'vip_iframe' => '<iframe width="100%" height="100%" src="' . 'https://'.Web_Url.links('vip','index',$myvideo->vid) . '" frameborder="0" allowfullscreen></iframe>',
					'vip_link' => 'https://'.Web_Url.links('vip','index',$myvideo->vid),
				];
			
		}

		return $this->output
			->set_content_type('application/json')
			->set_status_header(200)
			->set_output(json_encode([
				'status' => 'success',
				'msg' => '',
				'data' => $result
			]));
	}
		function document()
	{
		$this->load->view('head.tpl');
        $this->load->view('api/document.tpl');
        $this->load->view('bottom.tpl');
		
	}
}